﻿namespace Biblioteca
{
    public class Serie
    {
        private string genero;
        private string nombre;

        public Serie(string nombre,string genero):this()
        {
            this.nombre = nombre;
            this.genero = genero;
        }
        public Serie()
        {

        }

        public string Genero
        {
            get { return this.genero; }
            set { this.genero = value; }
        }
        public string Nombre
        {
            get { return this.nombre; }
            set { this.nombre = value; }
        }

        public override string ToString()
        {
            return $"Nombre: {this.Nombre} Genero:{this.Genero}";
        }

    }
}
