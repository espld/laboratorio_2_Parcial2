﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public delegate void DelegadoBacklog(Serie serie);
    public class ManejadorBacklog
    {
        public event DelegadoBacklog NuevaSerieParaVer;
        public void IniciarManejador(List<Serie> series)
        {
            Task task = new Task(() => MoverSeries(series));
            task.Start();
        }
        private void MoverSeries(List<Serie> series)
        {

            while (series.Count > 0)
            {
                int indice = ExtensoraRandom.GenerarRandom(series);
                Serie serie = series[indice];

                AccesoDatos.ActualizarSerie(serie);

                Thread.Sleep(1500);

                if (NuevaSerieParaVer is not null)
                {
                    NuevaSerieParaVer.Invoke(serie);
                }
            }

        }
    }
}
