﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Biblioteca
{
    public class Serializadora : IGuardar<List<Serie>>
    {
        public void Guardar(List<Serie> lista, string ruta)//XML
        {
            try
            {               
                using (StreamWriter sw = new StreamWriter(ruta))
                {
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Serie>));
                    xmlSerializer.Serialize(sw, lista);
                }
            }
            catch (Exception ex)
            {
                throw new BacklogException(ex.Message);
            }
        }

        void IGuardar<List<Serie>>.Guardar(List<Serie> lista, string ruta)//JSON
        {
            try
            {
                string objetoJson = JsonSerializer.Serialize(lista);
                File.WriteAllText(ruta, objetoJson);

            }
            catch (Exception ex)
            {

                throw new BacklogException(ex.Message);
            }
        }
    }
}
