﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public static class AccesoDatos
    {
        private static SqlCommand comando;
        private static SqlConnection conexion;

        static AccesoDatos()
        {
            comando = new SqlCommand();
            conexion = new SqlConnection("Data Source=.;Initial Catalog=20240701-SP;Integrated Security=True");
            comando.Connection = conexion;
            comando.CommandType = System.Data.CommandType.Text;
        }
        public static void ActualizarSerie(Serie item)
        {
            try
            {
                conexion.Open();
                comando.CommandText = "UPDATE dbo.series SET NOMBRE = @nombre, GENERO = @genero, ALUMNO = 'Lucas Espindola'";

                comando.Parameters.Clear();
                comando.Parameters.AddWithValue("@nombre",item.Nombre);
                comando.Parameters.AddWithValue("@genero",item.Genero);

                comando.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw new BacklogException(ex.Message);
            }
            finally
            {
                conexion.Close();
            }
        }
        public static List<Serie> ObtenerBacklog()
        {
            List<Serie> listaSeries = new List<Serie>();

            try
            {
                conexion.Open();
                comando.CommandText = "SELECT NOMBRE, GENERO FROM dbo.series";
                SqlDataReader lector = comando.ExecuteReader();

                while(lector.Read())
                {
                    Serie serie = new Serie(lector["NOMBRE"].ToString(), lector["GENERO"].ToString());
                    listaSeries.Add(serie);
                }

                lector.Close();
            }
            catch (Exception ex )
            {

                throw new BacklogException(ex.Message);
            }
            finally
            {
                conexion.Close();
            }

            return listaSeries;
        }

    }
}
