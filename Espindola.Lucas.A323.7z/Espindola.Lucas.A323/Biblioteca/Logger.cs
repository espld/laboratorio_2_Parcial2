﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class Logger
    {
        public static void Log(string mensaje)
        {
            string ruta = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "log.txt");

            try
            {
                string datos = $"Mensaje: {mensaje} - Fecha y hora actual: {DateTime.Now}";
                File.WriteAllText(ruta, datos);
            }
            catch (Exception ex)
            {

                throw new BacklogException(ex.Message);
            }
        }
    }
}
