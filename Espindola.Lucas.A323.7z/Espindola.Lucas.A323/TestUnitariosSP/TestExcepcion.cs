namespace TestUnitariosSP
{
    [TestClass]
    public class TestSerializacion
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}